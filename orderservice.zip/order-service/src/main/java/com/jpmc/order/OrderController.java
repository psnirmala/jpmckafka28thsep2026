package com.jpmc.order;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/orders")
public class OrderController {

    private final OrderProducer producer;

    public OrderController(OrderProducer producer) {
        this.producer = producer;
    }

    @PostMapping
    public String createOrder(
            @RequestBody OrderCreatedEvent event) {

        producer.sendOrder(event);

        return "Order sent to Kafka";
    }
}