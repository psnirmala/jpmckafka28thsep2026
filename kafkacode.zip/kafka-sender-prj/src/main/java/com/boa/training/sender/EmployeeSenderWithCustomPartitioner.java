package com.boa.training.sender;

import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

import com.boa.training.domain.Employee;
import com.boa.training.partitioner.EmployeePartitioner;
import com.boa.training.serializer.EmployeeSerializer;

public class EmployeeSenderWithCustomPartitioner {
	public static void main(String[] args) {
		String topic="emp-topic";
		Properties props=new Properties();
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,"localhost:9092");
		props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,StringSerializer.class.getName());
		props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,EmployeeSerializer.class.getName());
		props.put(ProducerConfig.PARTITIONER_CLASS_CONFIG, EmployeePartitioner.class.getName());
		//<String,String> denotes that both key and value are in string format
		KafkaProducer<String, Employee> producer=new KafkaProducer<String, Employee>(props);
		for(int i=1001;i<=1010;i++) {
			//each message is in the form of producer record object
			Employee employee=new Employee(i, "Name "+i, "Developer");
			ProducerRecord<String, Employee> record=new ProducerRecord<String,Employee>(topic,employee);
			producer.send(record);
		}
		for(int i=2001;i<=2010;i++) {
			//each message is in the form of producer record object
			Employee employee=new Employee(i, "Name "+i, "Accountant");
			ProducerRecord<String, Employee> record=new ProducerRecord<String,Employee>(topic,employee);
			producer.send(record);
		}
		for(int i=3001;i<=3010;i++) {
			//each message is in the form of producer record object
			Employee employee=new Employee(i, "Name "+i, "Architect");
			ProducerRecord<String, Employee> record=new ProducerRecord<String,Employee>(topic,employee);
			producer.send(record);
		}
		System.out.println("messages sent");
		producer.close();
		
	}

}
