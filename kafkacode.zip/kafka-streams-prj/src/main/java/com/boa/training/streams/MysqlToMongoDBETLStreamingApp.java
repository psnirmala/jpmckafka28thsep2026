package com.boa.training.streams;

import java.util.Properties;

import org.apache.kafka.common.serialization.Serdes.StringSerde;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.KStream;

import com.boa.training.domain.Employee;
import com.boa.training.serde.EmployeeSerde;

public class MysqlToMongoDBETLStreamingApp {
	public static void main(String[] args) {
		Properties props=new Properties();
		props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, StringSerde.class.getName());
		props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, EmployeeSerde.class.getName());
		props.put(StreamsConfig.APPLICATION_ID_CONFIG, "mysql-mongodb-etl-app");
		KafkaStreams streams=new KafkaStreams(createTopology(), props);
		streams.start();
		System.out.println("streaming started");
		try {
			Thread.sleep(10*60*1000);
		}catch (InterruptedException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		streams.close();
		System.out.println("streaming stopped");
		
	}
	
	static Topology createTopology() {
		StreamsBuilder builder=new StreamsBuilder();
		String inputTopic="mysql-topic-employee";
		String outputTopic="mongodb-topic-employee";
		KStream<String, Employee> inputStream=builder.stream(inputTopic);
		KStream<String, Employee> transformedStream=inputStream.mapValues(v->{
			System.out.println("processing  employee with id "+v.getEmpId());
			String designation=v.getDesignation();
			double salary=40000;
			if(designation.equals("Developer")) {
				salary=50000;
				
			}
			else if(designation.equals("Accountant")) {
				salary=35000;
				
			}
			else if(designation.equals("Architect")) {
				salary=80000;
				
			}
			Employee transformed=new Employee(v.getEmpId(), v.getName(), designation);
			transformed.setSalary(salary);
			return transformed;
		});
		transformedStream.to(outputTopic);
		return builder.build();
	}

}
