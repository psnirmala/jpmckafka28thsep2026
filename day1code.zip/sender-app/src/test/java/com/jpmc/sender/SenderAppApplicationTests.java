package com.jpmc.sender;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SenderAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
