package com.boa.training.receiver;

import java.time.Duration;
import java.util.Collections;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;

import com.boa.training.deserializer.EmployeeDeserializer;
import com.boa.training.domain.Employee;


public class EmployeeReceiver {
	public static void main(String[] args) {
		
		Properties props=new Properties();
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,"localhost:9092");
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class.getName());
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,EmployeeDeserializer.class.getName());
		props.put(ConsumerConfig.GROUP_ID_CONFIG,"emp-group-1");
		
		//<String,String> denotes that both key and value are in string format
		KafkaConsumer<String, Employee> consumer=new KafkaConsumer<String, Employee>(props);
		consumer.subscribe(Collections.singletonList("emp-topic"));
		Runtime.getRuntime().addShutdownHook(new Thread() {
			public void run() {
				consumer.close();
			}
		});
		System.out.println("waiting for messages.....");
		while(true) {
			ConsumerRecords<String, Employee> records=consumer.poll(Duration.ofSeconds(20));
			for(ConsumerRecord<String, Employee> record:records) {
				System.out.println("key: "+record.key()+"\tpartition: "+record.partition());
				Employee employee=record.value();
				System.out.println(employee.getEmpId()+"\t"+employee.getName()+"\t"+employee.getDesignation());
			}
		}
		
	}

}
