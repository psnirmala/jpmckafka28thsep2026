package com.jpmc.samplerest.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jpmc.samplerest.domain.Employee;
import com.jpmc.samplerest.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	private final EmployeeRepository repository;
	
	
	
	public EmployeeService(EmployeeRepository repository) {
		super();
		this.repository = repository;
	}

	public Employee createEmployee(Employee employee) {
		return repository.save(employee);
	}

	public List<Employee> getAllEmployees(){
		return repository.findAll();
	}
	
	public Optional<Employee> getEmployeeById(Integer id){
		return repository.findById(id);
	}
	
	public Employee updateEmployee(Integer id, Employee employee) {
		Employee existingEmployee=repository.findById(id).orElseThrow(()->new RuntimeException("Employee not found"));
		existingEmployee.setName(employee.getName());
		existingEmployee.setDesignation(employee.getDesignation());
		return repository.save(existingEmployee);
	}
	
	public void deleteEmployee(Integer id) {
		if(!repository.existsById(id)) {
			throw new RuntimeException("Employee not found");
		}	
		repository.deleteById(id);	
		
	}
}
