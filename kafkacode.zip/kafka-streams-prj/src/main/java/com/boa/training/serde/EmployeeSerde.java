package com.boa.training.serde;

import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serializer;

import com.boa.training.deserializer.EmployeeDeserializer;
import com.boa.training.domain.Employee;
import com.boa.training.serializer.EmployeeSerializer;

public class EmployeeSerde implements Serde<Employee> {

	@Override
	public Serializer<Employee> serializer() {
		// TODO Auto-generated method stub
		return new EmployeeSerializer();
	}

	@Override
	public Deserializer<Employee> deserializer() {
		// TODO Auto-generated method stub
		return new EmployeeDeserializer();
	}

}
