package com.jpmc.samplerest.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpmc.samplerest.domain.Employee;


public interface EmployeeRepository extends 
JpaRepository<Employee, Integer>{

}
