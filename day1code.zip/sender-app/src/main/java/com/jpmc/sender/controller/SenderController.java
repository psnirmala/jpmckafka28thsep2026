package com.jpmc.sender.controller;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/kafka")
public class SenderController {
	private final KafkaTemplate<String, String> template;

	public SenderController(KafkaTemplate<String, String> template) {
		super();
		this.template = template;
	}
	
	@PostMapping("/msg")
	public String sendMessage(@RequestParam String message) {
		template.send("test-topic",message);
		return "message sent";
	}

}
