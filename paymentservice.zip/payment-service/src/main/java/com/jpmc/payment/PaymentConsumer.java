package com.jpmc.payment;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class PaymentConsumer {

    @KafkaListener(
        topics = "order-created",
        groupId = "payment-group"
    )
    public void consume(OrderCreatedEvent event) {

        System.out.println(
            "Payment processing for order: "
            + event.getOrderId()
        );

        System.out.println(
            "Product: " + event.getProduct()
        );

        System.out.println(
            "Amount: " + event.getAmount()
        );
    }
}