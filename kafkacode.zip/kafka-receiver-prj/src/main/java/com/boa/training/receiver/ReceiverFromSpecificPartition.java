package com.boa.training.receiver;

import java.time.Duration;
import java.util.Collections;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;


public class ReceiverFromSpecificPartition {
	public static void main(String[] args) {
		
		Properties props=new Properties();
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,"localhost:9092");
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class.getName());
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class.getName());
	
		
		//<String,String> denotes that both key and value are in string format
		KafkaConsumer<String, String> consumer=new KafkaConsumer<String, String>(props);
		int partitionNumber=Integer.parseInt(args[0]);
	
		TopicPartition partition=new TopicPartition("sample-topic", partitionNumber);
		
		consumer.assign(Collections.singletonList(partition));
		Runtime.getRuntime().addShutdownHook(new Thread() {
			public void run() {
				consumer.close();
			}
		});
		System.out.println("waiting for messages from partition "+partitionNumber);
		while(true) {
			ConsumerRecords<String, String> records=consumer.poll(Duration.ofSeconds(20));
			for(ConsumerRecord<String, String> record:records) {
				System.out.println("key: "+record.key()+"\tvalue: "+record.value()
				+"\tpartition: "+record.partition()+"\toffset: "+record.offset());
			}
			
		}
		
	}

}
