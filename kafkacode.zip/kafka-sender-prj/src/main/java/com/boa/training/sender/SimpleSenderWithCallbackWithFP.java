package com.boa.training.sender;

import java.util.Properties;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;

public class SimpleSenderWithCallbackWithFP {
	public static void main(String[] args) {
		String topic="sample-topic";
		Properties props=new Properties();
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,"localhost:9092");
		props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,StringSerializer.class.getName());
		props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,StringSerializer.class.getName());
		
		//<String,String> denotes that both key and value are in string format
		KafkaProducer<String, String> producer=new KafkaProducer<String, String>(props);
		for(int i=1;i<=10;i++) {
			//each message is in the form of producer record object
			ProducerRecord<String, String> record=new ProducerRecord<String, String>(topic,"first-key","This is message "+i);
			producer.send(record,(rmd, exception)-> {
					// TODO Auto-generated method stub
					if(exception==null) {
						System.out.println("message successfully published in partition "+rmd.partition()+" at offset "+rmd.offset());
					}
				});
			
		}
		
		System.out.println("messages sent");
		producer.close();
		
	}

}
