package com.boa.training.deserializer;

import java.io.IOException;

import org.apache.kafka.common.serialization.Deserializer;

import com.boa.training.domain.Employee;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EmployeeDeserializer implements Deserializer<Employee>{
	private ObjectMapper mapper=new ObjectMapper();
	@Override
	public Employee deserialize(String topic, byte[] data) {
		// TODO Auto-generated method stub
		Employee employee=null;
		try {
			employee=mapper.readValue(data,Employee.class);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return employee;
	}

}
