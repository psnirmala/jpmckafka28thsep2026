package com.boa.training.receiver;

import java.time.Duration;
import java.util.Collections;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;


public class ReceiverWithAutoOffsetReset {
	public static void main(String[] args) {
		
		Properties props=new Properties();
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,"localhost:9092");
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class.getName());
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class.getName());
		props.put(ConsumerConfig.GROUP_ID_CONFIG,"group-4");
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		
		//<String,String> denotes that both key and value are in string format
		KafkaConsumer<String, String> consumer=new KafkaConsumer<String, String>(props);
		consumer.subscribe(Collections.singletonList("sample-topic"));
		Runtime.getRuntime().addShutdownHook(new Thread() {
			public void run() {
				consumer.close();
			}
		});
		System.out.println("waiting for messages.....");
		while(true) {
			ConsumerRecords<String, String> records=consumer.poll(Duration.ofSeconds(20));
			for(ConsumerRecord<String, String> record:records) {
				System.out.println("key: "+record.key()+"\tvalue: "+record.value()
				+"\tpartition: "+record.partition()+"\toffset: "+record.offset());
			}
		}
		
	}

}
