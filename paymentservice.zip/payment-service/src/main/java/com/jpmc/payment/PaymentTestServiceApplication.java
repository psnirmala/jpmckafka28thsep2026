package com.jpmc.payment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentTestServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentTestServiceApplication.class, args);
	}

}
