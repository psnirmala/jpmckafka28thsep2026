package com.jpmc.order;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderTestServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderTestServiceApplication.class, args);
	}

}
