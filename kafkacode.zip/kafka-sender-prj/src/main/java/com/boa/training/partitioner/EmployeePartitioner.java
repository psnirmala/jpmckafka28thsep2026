package com.boa.training.partitioner;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Properties;

import org.apache.kafka.clients.producer.Partitioner;
import org.apache.kafka.common.Cluster;

import com.boa.training.domain.Employee;

public class EmployeePartitioner implements Partitioner {
	private Properties props=new Properties();
	@Override
	public void configure(Map<String, ?> configs) {
		// TODO Auto-generated method stub
		System.out.println("*******************configuring*******************");
		InputStream in=EmployeePartitioner.class.getResourceAsStream("/designation.properties");
		try {
			props.load(in);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public int partition(String topic, Object key, byte[] keyBytes, Object value, byte[] valueBytes, Cluster cluster) {
		// TODO Auto-generated method stub
		int partition=3;
		Employee employee=(Employee)value;
		String designation=employee.getDesignation();
		if(props.containsKey(designation)) {
			partition=Integer.parseInt(props.getProperty(designation));
		}
		
		System.out.println("sending message with designation: "+designation+" to partition "+partition);
		return partition;
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		System.out.println("*******************closing*******************");
	}

}



